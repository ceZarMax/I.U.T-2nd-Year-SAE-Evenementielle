/* simpleClientSocket.c */ 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <netdb.h> 
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>

/* declaration de variable globale du programme, ces variable sont critiques 
    elle sont globale pour une meilleur gestion d'erreur et d'interruption*/
int sockfd, portno, n; 

/*On definit la gestion d'interuption qui nous permet de 
arreter le programme en fermant les socket ouvert pour 
netoyer les socket et les processus a chaque interruption du programme*/
void interrupt_handler(int sig) {
    printf("Socket interrupted. Closing socket and cleaning up...\n");
    close(sockfd);  //ferme le socket
    exit(1);
}

/*On definit la gestion de timeout qui permet de 
arreter les programme en cours et de netoyer les processus en cours
de fermer les socket a chaque timeout lors de l'attente de reponse du serveur*/
void timeout_handler(){
    printf("Socket timeout\n");
    close(sockfd);  //ferme le socket
    exit(1);
}

/*Fonction d'affichage, une fonction qui nous permet de recuperer les liste 
d'étudiant pour les afficher a l'utilisateur seulement les information nessessaire*/

int fonction_affichage(int sock){
    
    /*Declaration de variable locale*/
    int n;
    char buffer[256]; 
    char str[256]; //
    
    /*On attend la confirmation du serveur*/
    alarm(3);   //On met une alarme pour eviter que le client attend trop longtemps, et on arrete si cela deplace
    bzero(buffer,256); 
    n = read(sock,buffer,256);
    alarm(0);
    
    if(strcmp(buffer,"ok")==0){ /*Si le message de l'accusée reception est bon alors on procede l'action*/

    /*On renvoie repond la confirmation du serveur */
        n = write(sock, "ok", strlen("ok"));

    /*On commence l'échange de données
    Grace a la boucle while et le protocole d'échange mise en place*/
        while(1){

            bzero(buffer,256); 
            n = read(sock,buffer,256);  //on attend l'envoie de données, ligne par ligne

            if(strcmp(buffer,"Fin")==0) /*Si on recoit un message 'fin' du serveur alors quitte la boucle de reception*/
                break;
        
            sprintf(str,"%s",buffer); /*On ajouter ligne par ligne dans une chaine de caractere */

            n = write(sock,"OK",strlen("OK"));  /*On envoie une accusée de reception au serveur*/
            
            printf("%s",str);   /*On affiche la ligne recue a l'utilisateur*/
        }
        printf("\n");   
        close(sock);    //On ferme le socket apres la fin de reception de donnée du serveur

    }
    /*Si l'accusée n'est pas bon, on affiche le message d'erreur envoyer par le serveur et on ferme le socket*/
    else{
        printf("erreur: %s", buffer);
        close(sock);
    }
    return 0;
}

int fonction_saisir_abscent(int sock){
    
    /*Déclaration de variable locale*/
    int n;
    char buffer[256]; 
            
        /*On attend l'affirmation du serveur pour continuer*/
    alarm(3);   //On met une alarme pour eviter que le client attend trop longtemps, et on arrete si cela deplace
    bzero(buffer,256); 
    n = read(sock,buffer,256);
    alarm(0);            
    buffer[strcspn(buffer, "\n")] = '\0';

        /*Si l'affirmation du serveur est bon alors on procede l'action*/
    if(strcmp(buffer,"ok")==0){
        bzero(buffer,256); 
        n = write(sock,"ok",strlen("ok"));

/*On rentre dans la boucle d'envoie de donner et d'echange entre le client serveur (partie critque)*/
        while(1){   

                /*On attend et ecoute les donnée que envoie le serveur*/             
            alarm(3);
            bzero(buffer,256);
            n = read(sock,buffer,256);
            alarm(0);

    /*mise en place du condition d'arret, Si on recoit un message 'fin' du serveur alors quitte la boucle de reception*/
            if(strcmp(buffer,"fin")==0){
                printf("serveur fin\n");
                break;
            }

    /*Apres avoir recues l'etudiant concerné, on attend le saisie de l'utilisateur (saisi d'abscence)*/
            printf("%s\n present saisi n, abscent saisi o\n",buffer);
            printf("faites votre choix: ");    
                    
            bzero(buffer,256); 
            fgets(buffer,255,stdin); //On recupere la saisie de l'utilisateur

            n = write(sock, buffer, strlen(buffer));    //On envoie la reponse au serveur
                        
            }
        
        close(sock);    //on ferme le socket apres la fin
            }

/*Si l'accusée n'est pas bon, on affiche le message d'erreur envoyer par le serveur et on ferme le socket*/
    else{
        printf("erreur: %s\n", buffer);
        close(sock);
        }
    return 0;
}


 
int main(int argc, char *argv[]) 
{ 

    /*On définit le format d'adressage*/
    struct sockaddr_in serv_addr; 
    struct hostent *server; 
     
    char buffer[256]; //On declare le buffer, pour recuperation et envoie de données
     
     /*On definit l'instruction au cas ou l'utilisateur ne savent pas utiliser*/
    if (argc < 3 ) { 
        fprintf(stderr,"usage %s hostname port\n", argv[0]); 
        exit(0); 
    } 
    portno = atoi(argv[2]); //On recupere le numéro de port
     
    /* On créer le socket */ 
    sockfd = socket(PF_INET, SOCK_STREAM, 0); 
    
    signal(SIGINT,interrupt_handler);   //On met en place la detection d'interruption pour appel du gestionnaire d'interruption
    signal(SIGALRM, timeout_handler);   //On met en place la detection de timeout pour appel du gestionnaire de timeout
     
    server = gethostbyname(argv[1]); //On recupere le nom et l'adresse de la machine serveur
     
    //bzero((char *) &serv_addr, sizeof(serv_addr)); 
    serv_addr.sin_family = AF_INET; //definition du type
    bcopy((char *)server->h_addr, // identique à memcpy 
        (char *)&serv_addr.sin_addr.s_addr, server->h_length); 
 
    serv_addr.sin_port = htons(portno); //definition du port d'ecoute
     
    /* Connexion vers le serveur */ 
    if((connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)))==0){ 

        /*Si elle est aboutie alors on effectue les actions*/
        printf("Voudriez vous selectionner un des groupe pour effectuer l'appel.\n");
        printf("1 -> RT1FI\n2 -> RT1FA\n3 -> RT2FI\n4 -> RT2FA\n ");
        printf("faites votre choix:  ");

    /*On recupere la selection du client concernant le groupe d'appel*/
        bzero(buffer,256); 
        fgets(buffer,255,stdin);    //on recupere le saisie
        buffer[strcspn(buffer, "\n")] = '\0';

    /*On verifie la selection de l'utilateur
    on met envoie au serveur le nom du fichier correspondant au numero*/
        if(strcmp(buffer,"1")==0){
            n = write(sockfd,"RT1FI_Appel.csv", strlen("RT1FI_Appel.csv")); //envoie du nom de fichier au serveur
        }
        else if(strcmp(buffer,"2")==0){
            n = write(sockfd,"RT1FA_Appel.csv", strlen("RT1FA_Appel.csv")); //envoie du nom de fichier au serveur
        }
        else if(strcmp(buffer,"3")==0){
            n = write(sockfd,"RT2FI_Appel.csv", strlen("RT2FI_Appel.csv")); //envoie du nom de fichier au serveur
        }
        else{
            n = write(sockfd,"RT2FA_Appel.csv", strlen("RT2FA_Appel.csv")); //envoie du nom de fichier au serveur
        }

    //On attend un accuse de reception du serveur
        alarm(3);
        bzero(buffer,256); 
        n = read(sockfd,buffer,256);
        buffer[strcspn(buffer, "\n")] = '\0';
        alarm(0);

        if(strcmp(buffer,"ok")==0){ //si l'accuse de reception est bonne alors on realise l'action

        /*On demande l'action que l'utilisateur voudrais que le serveur fasse*/
            printf("voudriez vous saisir l'action:\n saisi 1 pour faire l'appel , saisi 2 pour l'affichage ...\n");
            printf("faites votre choix:  ");
        
            bzero(buffer,256); 
            fgets(buffer,255,stdin); //On recupere la selection de l'utilisateur
            buffer[strcspn(buffer, "\n")] = '\0';

            if(strcmp(buffer,"1") == 0){
                n = write(sockfd,"noter",strlen("noter"));  //on envoie la selection su client au serveur, l'action noter
                fonction_saisir_abscent(sockfd);    //On fait appele a la fonction saisir abscent
                
            }
                
            else if(strcmp(buffer,"2")==0){
                n = write(sockfd,"afficher",strlen("afficher"));    //on envoie la selection su client au serveur, l'action afficher
                fonction_affichage(sockfd); //On fait appele a la fonction saisir abscent
            }

        //selection d'action par defaut
            else{
                n = write(sockfd,"afficher",strlen("afficher"));    //on envoie la selection su client au serveur, l'action afficher
                fonction_affichage(sockfd); //On fait appele a la fonction saisir abscent
            }
        }

        else{   //si la reponse du serveur n'est pas desirer alors on affiche le probleme renvoyer et ferme le socket
            printf("error:%s\n", buffer);
            close(sockfd);
            exit(1);
        }
    }

    /*Si la connexion au serveur n'a pas pue aboutie alors on ferme le socket, afficher le message d'erreur et arrete le programme*/
    else{
        printf("La connexion au Serveur n'a pas pu etre aboutie.\n Verifiez votre connexion.\n");
        close(sockfd);
        return 0; 
    }
    
    return 0;
 }
