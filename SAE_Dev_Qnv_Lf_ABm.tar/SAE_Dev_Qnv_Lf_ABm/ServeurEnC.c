/* multipleServerSocket.c */ 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>


/* declaration de variable globale du programme, ces variable sont critiques 
    elle sont globale pour une meilleur gestion d'erreur et d'interruption*/
int sockfd, newsockfd, portno; 
pid_t pid;

/*Gestionnaire de l'interruption avec les signaux
elle permet de netoyer, de fermer les socket, de joindre les processus pour 
eviter les processus zombie qui pourrait nuire au bon fonctionnement du programme*/
void interrupt_handler(int signo) {
    printf("Socket interrupted. Closing socket and cleaning up...\n");
    write(newsockfd,"fin", strlen("fin"));  //on envoie le message fin au client
    close(newsockfd);   //on ferme le socket fils
    close(sockfd);  //On ferme le socket principale
    waitpid(pid, NULL, 0);  //on joindre les pocessus fils du pere
    exit(0);
}

/*Fonction de création de feuille d'appel permet de creer une fichier d'appel
selon la feuille d'information sur les etudiants fournie, elle permet de creer 
un format plus simplifier que la feuille model, ce qui permet une meilleur compréhension
et une meilleur simplification lors des modification.*/
int creation_feuille_appel(char fichier_entrant[], char fichier_sortant[]){
    
    /*On declare les deux different pointeur de fichier
    un pour la lecture du fichier entrant et l'autre pour la lecture 
    du fichier sortant*/
    FILE *fp ;
    FILE *fp2;

    //on ouvre le fichier entrant pour recuperer les données
    if ((fp = fopen(fichier_entrant, "r+")) != NULL) {  
        
        if((fp2 = fopen(fichier_sortant, "w")) != NULL){  //On ouvre et creer le deuxieme fichier pour ecrire dessus
            
            int ligne = 0;  //numero de ligne, (compteur)
            char line[1024];//String line pour recuperation ligne par ligne
            
            while (fgets(line, sizeof(line), fp) != NULL) {
                
                int collone = 0; //compteur de collone 
                char *string, *chunk;   //pointeur de chaine de carractere, utile pour utiliser strsep
                string = strdup(line);  //point la ligne qu'on veut parser

                if(ligne == 0){ //si c'est le premier ligne alors on met le mise en page du csv
                    fprintf(fp2,"code_nip;nom;prenom;presence\n"); //on met les titre dans le csv
                }

    //Pour les autres ligne, on va parser les element et le mettre dans le nouveau fichier
                else    
                {
                    while((chunk=strsep(&string,";")) != NULL)  //On recupere les element collonne par collone avec strsep
                    {   
                        if(collone == 1){   //si c'est le premier collonne alors on passe la valeurs du code nip
                            fprintf(fp2,"%s;",chunk);
                            }

                        else if(collone == 4){  //si c'est le 4e collonne alors on passe la valeurs du nom
                            fprintf(fp2,"%s;",chunk);
                            }

                        else if(collone == 6){  //si c'est le 6e collonne alors on passe la valeurs du prenom
                            fprintf(fp2,"%s;oui\n",chunk);
                            }

                        collone += 1;
                    }
                }   

                ligne += 1;
            }
        }
    /*Si l'ouverture du fichier entrant et la création du fichier sortant n'effectue pas
    alors on sorte le message d'erreur, on ferme les pointeur et on sort du fonction*/
        else   
        {
            printf("error d'ouverture du ficher: %s", fichier_sortant);
            fclose(fp);
            fclose(fp2);
            exit(1);
        }
    }
    else
    {
        printf("error d'ouverture du ficher: %s", fichier_entrant);
        fclose(fp);
        exit(1);
    }
    fclose(fp);
    fclose(fp2);
    return 0;
    }

        /*Fonction mettre abscent va nous permettre de noter les abscent dans un fichier 
        dedier, de modifier ce fichier selon le status presence de chaque etudiant
        Elle va prend comme parametre le fichier a modifier (Fichier), le numero de l'étudiant 
        en question (num_etudiant) et le status (Status)*/

int Mettre_Absent(char Fichier[50], char num_etudiant[50], char Status[50]) {
  
  FILE *fp ;//declaration du pointeur de fichier fp
  
  /*On essaye de ouvrir le fichier et verifie si elle existe
  si elle existe alors on effectue les actions nessaissaire*/
  if ((fp = fopen(Fichier, "r+")) != NULL) {
    
    char line[1024];    //variable line, pour recuperation de chaque ligne
    
    /*On commence la récupération ligne par ligne jusqu'a la fin du fichier*/
    while (fgets(line, sizeof(line), fp) != NULL) { 
  
  /*on compare le numero etudiant passée en parametre avec chaque ligne du fichier avec strstr
  Si il ya une similitude alors on va modifier ce ligne spécifique*/
      if (strstr(line, num_etudiant) != NULL) { 

        fseek(fp, -strlen(line), SEEK_CUR); //On retour au debut d'une ligne avec fseek

        //On declare les variable qui nous sert a parser les éléments
        char  number[20],last_name[20], prenom[20], status[20];

    /*On declare les pointeur qui nous serons utile pour l'utilisation de strsrep
    une fonction qui separe les element selon les separateur*/
        char *string, *chunk;
        string = strdup(line);

    /*On parse les element d'une ligne selon les séparateur ';'
    pour les mettre dans le variable*/
        chunk=strsep(&string,";");
        strcpy(number,chunk);
        chunk=strsep(&string,";");
        strcpy(last_name,chunk);
        chunk=strsep(&string,";");
        strcpy(prenom,chunk);
        chunk=strsep(&string,";");
        strcpy(status,chunk);

    //On modifie la ligne en remplacant par une autre ligne avec le status modifier
        fprintf(fp,"%s;%s;%s;%s\n",number,last_name,prenom,Status);
        
        break; //on sort du programme
        }
    }
    }
    fclose(fp);
    return 0;
}

                    /*Fonction qui permet de saisir les abscent
    Cette fonction envoie des nom au client pour effectuer appel eleves par eleves
    cette fonction prend en parametre le nom du fichier et le descripteur de socket en entier*/
int Saisir_absent(char fichier[256],int sock){
    
    /*Declaration de variable*/
    char buffer[256];
    bzero(buffer,256);
    int n;
    FILE *fp ;

    
    if ((fp = fopen(fichier, "r+")) != NULL) { //ouvre le fichier et verifier si elle ouvre bien
        
        n = write(sock,"ok",strlen("ok")); //On envoie un accuse de reception au client pour assurer que cela fonctionne
        
        bzero(buffer,256);  //On attend l'accuser du client
        n = read(sock,buffer,255);

        if(strcmp(buffer,"ok")==0){ //si l'accusé est positif alors on effectuer l'action
            
            //Declaration de variable pour le parsing de donnée
            char number[256],last_name[20], prenom[20];
            char line[1024];    //Chaine de caractere line pour recuperation ligne par ligne
            int ligne = 0; //On initie le comptage de ligne à 0

            /*On recupere les donnée ligne par ligne 
            jusqu'a la fin du fichier avec un boucle tant que.*/
            while (fgets(line, sizeof(line), fp)) { 
                
                if(ligne > 0){  
                //si la ligne est au dela du premier ligne alors on effectue l'operation souhaiter
                    
                    char *string, *chunk;  //on declare les pointeur de caractere, utile pour utilisation de strsep 
                    string = strdup(line);

                    /*On effectue le parsing des donnée desirer avec strsep, 
                    avec ';' comme separateur*/
                    chunk=strsep(&string,";"); //on passe d'un element apres ';'
                    strcpy(number,chunk); //On met la variable parsé dans une variable
                    chunk=strsep(&string,";");  //on passe d'un element apres ';'
                    strcpy(last_name,chunk);//On met la variable parsé dans une variable
                    chunk=strsep(&string,";");  //on passe d'un element apres ';'
                    strcpy(prenom,chunk);//On met la variable parsé dans une variable

                //on les conctatene tous les variable parser dans une chaine line
                    sprintf(line,"%s %s",last_name,prenom); 

                //On Envoie cette chaine line au client
                    n = write(sock,line,strlen(line)); 
                
                //On attend la reponse du client concernant l'abscence de cette client
                    bzero(buffer,256);
                    n = read(sock,buffer,255);
                    buffer[strcspn(buffer, "\n")] = '\0';

                /*on recupere la reponse du client et mettre les abscent et present
                selon la reponse*/

                    //si la reponse du client est un 'o'
                    if(strcmp(buffer,"o")==0){
                        char status[256] = "oui";  //On definit le status comme oui
                        Mettre_Absent(fichier,number,status);//On appelle la fonction Mettre_Abscent
                    }

                    else if(strcmp(buffer,"n")==0){
                        char status[256] = "non";
                        Mettre_Absent(fichier,number,status);
                    }
                        /*Le status par defaut sera un non*/ 
                    else{
                        char status[256] = "non";
                        Mettre_Absent(fichier,number,status);
                    }
                }
                ligne += 1; //On incrément la ligne de 1 a chaque recuperation de ligne
            }

            fclose(fp); //on ferme fp, pointeur de fichier
            //on envoie un message d'arret au client pour arrete sa reception de donnée
            write(sock,"fin",strlen("fin"));    
            close(sock);    //on ferme sock
        }
            /*Si l'accuse de reception du client n'est pas bon alors on arrete le programme
            et n'etoie les variable*/
        else{
            fclose(fp); //on ferme fp, pointeur de fichier
            printf("Erreur, accuser du client non recue");
            close(sock); //on ferme sock
            exit(0);    //on fait une sorte d'erreur
        }

        return(0);}
}

    /*La fonction d'affichage va permettre de d'envoyer les table d'abscence au client*/
void Fonction_affichage(int sock, char Fichier[256]){
        
        /*declation de variables*/
        int n;
        char buffer[256];
        char row[256];
        FILE * fp;
        
        //On verifie l'ouverture du fichier
        if ((fp = fopen(Fichier, "r")) != NULL) {
            n = write(sock, "ok", strlen("ok")); //on envoie une accusé de reception au client

                /*On attend un accusé de reception du client*/
            bzero(buffer,256);
            n = read(sock,buffer,255); 

                /*Si l'accusé de reception est bon, on fait va commencer l'envoie de donnée*/
            if(strcmp(buffer,"ok")==0){     
            
                    // Lecture du fichier ligne par ligne
                while (fgets(row, sizeof(row), fp))  
                {
                    /*Lit une ligne du fichier et la stocke dans le chaine de caractere row
                    effectuer en bloucle*/

                    // Envoie la ligne lue au client
                    n = write(sock, row, strlen(row) + 1);
                    
                    // attendre une réponse du client car read() est bloquante
                    bzero(buffer,256);
                    n = read(sock, buffer, 255);
        
                }

                // Fermeture du fichier
                fclose(fp); 
                // Envoie un message de fin au client
                n = write(sock, "Fin", strlen("Fin"));
                // Fermeture de la socket de connexion
                close(sock);}

            else{
                close(sock);// Fermeture de la socket de connexion si il ya une erreur du client
                }
        }
            /*Si l'ouverture du fichier a échoué, on envoie un message d'erreur au client*/ 
        else
            {   
            // Création de la variable message en chaine de caractère
            char message[256];
           
            // Construire le message d'erreur qui indique que le fichier n'a pas pu être ouvert . 
            sprintf(message, "FileError"); // spintf nous permet d'écrire un texte dans un tableau de caractère
            // Affiche le message d'erreur
            printf("%s", message);
            // Ensuite on envoie le message au client via la fonction write
            n = write(sock, message, strlen(message));
            // Fermeture de la socket connecter au client
            close(sock);
            }
}

/*On definit la fonction principale */
/*Cette fonction nous permet de gerer les demande du client vis a vis du serveur*/
              
void Fonction_Pricipale(int sock){
    
    int n; //declarer l'entier n
    char buffer[256]; //declarer le chaine de caractere buffer
    char Fichier[256]; //declarer le chaine de caractere Fichier
      
    
    bzero(buffer,256); // nétoyer le buffer
    n = read(sock,buffer,255); //ecoute une proposition du client concernant le fichier d'appel
    buffer[strcspn(buffer, "\n")] = '\0';
    
        /*On verifie la demande du client, 
            si le fichier demandé existe*/
    if (access(buffer, F_OK) != -1) {   //On verifie si le fichier existe
        strcpy(Fichier,buffer);    //on copy le nom du fichier desirer dans une chaine de caracatere locale
        n = write(sock,"ok",strlen("ok")); //On renvoie une accuser de reception au client

        bzero(buffer,256); 
        n = read(sock,buffer,255);  //On attend la reponse au client pour passer a une autre question
        buffer[strcspn(buffer, "\n")] = '\0';

        /*On verifie les différent demande du client, 
            si il veut afficher ou faire l'appel*/

        if(strcmp(buffer,"noter")==0){      
            Saisir_absent(Fichier,sock); //on appelle la fonction Saisir_abscent
        }
    
        else if(strcmp(buffer,"afficher")==0){
            Fonction_affichage(sock,Fichier);  //On appelle la fonction affichage
        }
    
        close(sock);
    } 
        /*Si le groupe n'existe pas on envoie le message d'erreur au client
        et on ferme le socket de connexion*/
    else {  
        n = write(sock,"Groupe non existant",strlen("Groupe non existant"));
        close(sock);
        exit(1);
    }

    
}



int main( int argc, char *argv[] ) 
{ 
            //On creer une sorte de gestionnaire d'erreur et d'interruption pour le serveur 
    struct sigaction sa;  //On definit la structure sigaction sa
    sa.sa_handler = interrupt_handler; //  Pointer qui pointe vers la handler de interruption
    sigemptyset(&sa.sa_mask); //  On initisalise le set du signal vers vide
    sa.sa_flags = SA_RESTART; // Redemarrage automatic de appel system interromput
    sigaction(SIGINT, &sa, NULL); // Installe le nouvel gestionnaire de signal recue
    
    unsigned int clilen;


    // On definit le format d'adressage
    struct sockaddr_in serv_addr, cli_addr; //format d'adressage pour serveur et client
    int  n; 
    //pid_t pid; 
     
    // Creation du socket
    sockfd = socket(PF_INET, SOCK_STREAM, 0); 

    // Apres la creation du socket, on definit et met en place une gestionnaire d'interuption
    signal(SIGINT,interrupt_handler);
     
    /* Definit la structure du socket*/
    bzero((char *) &serv_addr, sizeof(serv_addr)); 
    portno = 5001; //Definition du num de port d'écoute
     
     // On definit le plan et l'information d'adressage pour le serveur en replissant la structure
    serv_addr.sin_family = AF_INET; //definition du type 
    serv_addr.sin_addr.s_addr = INADDR_ANY; //definition de address ip
    serv_addr.sin_port = htons(portno);  //definition du port d'écoute
     
    /* On associer l'adress du serveur a un socket en utilisant bind().*/ 
    bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)); 
     
    /* On va maintenant attendre la connection du client avec listen
        cela va mettre le serveur en ecoute et en attedant la connexion
        d'un client pour l'accepter */ 
    listen(sockfd,5); 
    clilen = sizeof(cli_addr); 
     
                                //CREATION DE FEUILLE APPEL

    /* Appelle de la fonction creation_feuille_appel pour effectuer la création des feuille d'appel 
     a partir des fichier csv principale, cela est effectuer pour tous les groupe lors du demarage du serveur.*/
    struct stat buffer;
    
    if (stat("RT1FI.csv", &buffer) == 0 && stat("RT1FA.csv", &buffer) == 0 && stat("RT2FI.csv", &buffer) == 0 && stat("RT2FA.csv", &buffer) == 0) {
        creation_feuille_appel("RT1FI.csv", "RT1FI_Appel.csv");
        creation_feuille_appel("RT1FA.csv", "RT1FA_Appel.csv");
        creation_feuille_appel("RT2FI.csv", "RT2FI_Appel.csv");
        creation_feuille_appel("RT2FA.csv", "RT2FA_Appel.csv");
        while (1) 
        { 
            newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,  
                            &clilen);

            
            /* creation de processus fils */ 
            pid = fork(); 
            
            if (pid == 0) 
            { 
                /* processus pour client */ 
                close(sockfd); 
                Fonction_Pricipale(newsockfd); //On appel la fonction principale pour client.
                exit(0); 
            } 
            else 
            { 
                close(newsockfd); //On ferme la socket pour client si il ya une erreur.
            } 
        } 
    }

    else{
        printf("une ou plusieurs fichier csv models sur les etudiant n'existe pas\n voudriez nous l'importer dans le fichier pour continuez\n");
        return 1;
    }

    
}