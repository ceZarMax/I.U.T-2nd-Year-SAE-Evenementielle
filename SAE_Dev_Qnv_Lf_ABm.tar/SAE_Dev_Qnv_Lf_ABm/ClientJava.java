import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Optional;
import java.util.Scanner;

// Client.java 

public class ClientJava { // Classe ClientJava

    /* Déclaration d'attribut */

    private Socket sockfd; // attribut sockfd de type Socket
    private DataOutputStream enSortie; // attribut enSortie de type DataOutputStream, pour reception
    private DataInputStream enEntree; // attribut enEntree de type DataInputStream, pour l'envoie

    public ClientJava(String hote, String port) {

        /* Déclaration de variable local */

        int portno = Integer.parseInt(port);
        byte[] buffer; // on lit/écrit des octets dans la socket
        byte[] groupe; // stockage de groupe
        int n;
        String message; // pour reception des message
        Scanner clavier; // pour le saisie d'utlisateur
        // String groupe;

        try { // mise en place le controle d'erreur
            sockfd = new Socket(hote, portno);
            enSortie = new DataOutputStream(sockfd.getOutputStream());
            enEntree = new DataInputStream(sockfd.getInputStream());

            System.out.printf("Entrez le groupe d'appel\n");
            System.out.printf("1 -> RT1FI\n2 -> RT1FA\n3 -> RT2FI\n4 -> RT2FA\n ");
            System.out.printf("Entrez le groupe d'appel\n");

            clavier = new Scanner(System.in); // On recupere le saisi de l'utilisateur
            String str = clavier.nextLine();

            /* Definir le groupe pour l'appel selon le choix du client */
            if (str.equals("1"))
                groupe = "RT1FI_Appel.csv".getBytes();

            else if (str.equals("2"))
                groupe = "RT1FA_Appel.csv".getBytes();

            else if (str.equals("3"))
                groupe = "RT2FI_Appel.csv".getBytes();
            else
                groupe = "RT2FA_Appel.csv".getBytes();

            enSortie.write(groupe, 0, groupe.length); // Envoie du groupe d'appel au serveur

            buffer = new byte[256];
            n = enEntree.read(buffer, 0, 255); // Lire l'accuser du serveur
            message = new String(buffer, 0, n);

            if (message.equals("ok")) { /*
                                         * Si le message renvoyer par le serveur est correct alors on passe a l'autre
                                         * question
                                         */

                /* Effectuer un deuxieme question: 'le choix de l'action' */
                System.out.println(
                        "voudriez vous saisir l'action:\n saisi 1 pour faire l'appel , saisi 2 pour l'affichage ...\n");
                clavier = new Scanner(System.in);
                System.out.println("faites votre choix:");

                str = clavier.nextLine(); // on recupere le saisie de l'utilisateur
                str = str.isEmpty() ? "1" : str; // si il ne rentre rien, la valeur 1 est par defaut

                if (str.equals("1")) { // Si le saisie est 1, on envoie le message "noter" au serveur et on appel la
                                       // fonction fonction_saisir_abscent()
                    buffer = new byte[256];
                    buffer = "noter".getBytes();
                    enSortie.write(buffer, 0, buffer.length);
                    fonction_saisir_abscent(); // appel la fonction fonction_saisir_abscent()
                }

                else if (str.equals("2")) { // Si le saisie est 2, on envoie le message "afficher" au serveur et on
                                            // appel la fonction affichag()
                    buffer = new byte[256];
                    buffer = "afficher".getBytes();
                    enSortie.write(buffer, 0, buffer.length);
                    affichage(); // appel la fonction affichag()
                }
            }

            else {
                System.out.println("Error:" + message); // si la reponse n'est pas bonne, on affiche le message d'erreur
                                                        // renvoyer par le client
                sockfd.close(); // on ferme le socket
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void fonction_saisir_abscent() {

        /* Déclaration de variable local */
        int n;
        byte[] buffer;
        byte[] OK;
        String ok = "ok";
        OK = ok.getBytes();
        Scanner clavier = new Scanner(System.in);

        try { // mise en place le controle d'erreur
            buffer = new byte[256];
            n = enEntree.read(buffer, 0, 255); // On attend la confirmation du serveur
            String message = new String(buffer, 0, n);

            if (message.equals("ok")) { // Si le messages est affirmatif du serveru alors on commence la reception et
                                        // envoie de données
                enSortie.write(OK, 0, 2); // On envoie une confirmation au serveur

                /* On ouvre la boucle pour l'échange de données avec le serveur */
                while (true) {
                    buffer = new byte[256];
                    n = enEntree.read(buffer, 0, 255);
                    message = new String(buffer, 0, n);

                    if (message.equals("fin")) { // Si le message renvoyer par le serveur est fin alors on arrete le
                                                 // reception et ferme le programme
                        sockfd.close();
                        System.out.println("serveur: " + message);
                        break;
                    }

                    clavier = new Scanner(System.in);
                    System.out.println(message + "\n present saisi n, abscent saisi o\n");

                    buffer = new byte[256];
                    String str = clavier.nextLine(); // On recupere le choix du client concernant le client renvoyer par
                                                     // le serveur
                    str = str.isEmpty() ? "o" : str; // la valeur par defaut si il ya rien est 'o'
                    buffer = str.getBytes();

                    enSortie.write(buffer, 0, buffer.length); // On envoie au serveur le choix du client pour l'etudiant
                }
                sockfd.close();
            } else {
                System.out.println("Erreur: " + message);// si la reponse n'est pas bonne, on affiche le message
                                                         // d'erreur renvoyer par le client
            }

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public void affichage() throws IOException {

        /* Declarationd e variable locale */
        int n;
        byte[] buffer;
        byte[] OK;

        String ok = "ok"; // definir le message d'acquittement "ok"
        OK = ok.getBytes();

        buffer = new byte[256];
        n = enEntree.read(buffer, 0, 255); // lit le message d'affirmation du serveur
        String message = new String(buffer, 0, n);

        if (message.equals("ok")) { // Si le message est bonne, on continue vers l'action
            enSortie.write(OK, 0, 2); // On envoie une message d'affirmation au serveur

            /*
             * On Ouvre la boucle infinie pour envoie et reception de données avec une
             * protocole spécifique
             */
            while (true) {

                buffer = new byte[256];
                n = enEntree.read(buffer, 0, 255); // on repurer une ligne du serveur
                message = new String(buffer, 0, n);

                if (message.equals("Fin")) { // Si le message renvoyer par le serveur est fin alors on arrete le
                                             // reception et ferme le programme
                    break;
                }

                enSortie.write(OK, 0, OK.length); // on envoie une accuser de reception

                System.out.println(message); // On affiche ligne par ligne

            }
            System.out.println("\n"); //
            sockfd.close(); // On ferme le socket
        } else {
            System.out.println("Erreur: " + message + "\n");
            sockfd.close();
        }

    }

    public static void main(String[] args) {
        new ClientJava(args[0], args[1]);
    }
}